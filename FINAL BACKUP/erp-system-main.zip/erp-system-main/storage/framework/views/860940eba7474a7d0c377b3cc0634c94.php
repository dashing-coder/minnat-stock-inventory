<?php $__env->startSection('title', $saleReturn->return_no); ?>
<?php $__env->startSection('heading', 'Sales Return ' . $saleReturn->return_no); ?>

<?php $__env->startSection('actions'); ?>
    <?php if($saleReturn->status === 'draft'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sale_returns.edit')): ?>
            <a href="<?php echo e(route('sale-returns.edit', $saleReturn)); ?>" class="btn btn-outline-primary">Edit</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sale_returns.post')): ?>
            <form class="d-inline" method="POST" action="<?php echo e(route('sale-returns.post', $saleReturn)); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-success">Post Return</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?><div class="card card-body"><p><b>Customer:</b> <?php echo e($saleReturn->customer?->name ?? 'Walk-in'); ?> &nbsp; <b>Warehouse:</b> <?php echo e($saleReturn->warehouse->name); ?> &nbsp; <b>Status:</b> <?php echo e($saleReturn->status); ?></p><table class="table"><thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody><?php $__currentLoopData = $saleReturn->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($i->product->name); ?></td><td><?php echo e($i->quantity); ?></td><td><?php echo e(number_format($i->unit_price,4)); ?></td><td><?php echo e(number_format($i->line_total,2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table><div class="text-end fs-5">Grand Total: <?php echo e(number_format($saleReturn->grand_total,2)); ?></div></div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/sale_returns/show.blade.php ENDPATH**/ ?>