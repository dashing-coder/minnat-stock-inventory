<?php $__env->startSection('title','Customer Ledger'); ?> <?php $__env->startSection('heading','Customer Ledger: '.$customer->name); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
<form class="row g-2 mb-3">
<div class="col-md-3"><input class="form-control" type="date" name="from_date" value="<?php echo e(request('from_date')); ?>"></div>
<div class="col-md-3"><input class="form-control" type="date" name="to_date" value="<?php echo e(request('to_date')); ?>"></div>
<div class="col-md-3"><input class="form-control" name="type" value="<?php echo e(request('type')); ?>" placeholder="Entry type"></div>
<div class="col"><button class="btn btn-outline-primary">Filter</button></div>
</form>
<div class="table-responsive"><table class="table"><thead><tr><th>Date</th><th>Reference</th><th>Type</th><th>Description</th><th class="text-end">Debit</th><th class="text-end">Credit</th><th class="text-end">Balance</th></tr></thead><tbody>
<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($e->transaction_date->format('Y-m-d')); ?></td><td><?php echo e($e->reference_no); ?></td><td><?php echo e($e->entry_type); ?></td><td><?php echo e($e->description); ?></td><td class="text-end"><?php echo e(number_format((float)$e->debit,2)); ?></td><td class="text-end"><?php echo e(number_format((float)$e->credit,2)); ?></td><td class="text-end"><?php echo e(number_format((float)$e->running_balance,2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody><tfoot><tr class="fw-bold"><td colspan="6">Closing Balance</td><td class="text-end"><?php echo e(number_format((float)$running,2)); ?></td></tr></tfoot></table></div>
<div class="small text-muted">Positive = customer owes company. Negative = customer advance.</div>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/customers/ledger.blade.php ENDPATH**/ ?>