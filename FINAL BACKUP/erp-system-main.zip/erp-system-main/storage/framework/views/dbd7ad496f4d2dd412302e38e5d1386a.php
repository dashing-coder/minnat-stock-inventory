<?php $__env->startSection('title','Purchases'); ?>
<?php $__env->startSection('heading','Purchases'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.create')): ?>
        <a class="btn btn-primary btn-sm" href="<?php echo e(route('purchases.create')); ?>"><i class="bi bi-plus-lg me-1"></i> New Purchase</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="erp-breadcrumbs mb-3"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a><i class="bi bi-chevron-right"></i><span>Purchases</span></div>

<div class="erp-stat-grid">
    <div class="erp-stat-card"><div class="erp-stat-icon blue"><i class="bi bi-receipt"></i></div><div><div class="erp-stat-label">Filtered Purchases</div><div class="erp-stat-value"><?php echo e(number_format($summary['count'])); ?></div></div></div>
    <div class="erp-stat-card"><div class="erp-stat-icon purple"><i class="bi bi-currency-dollar"></i></div><div><div class="erp-stat-label">Purchase Value</div><div class="erp-stat-value">৳ <?php echo e(number_format($summary['total'],2)); ?></div></div></div>
    <div class="erp-stat-card"><div class="erp-stat-icon green"><i class="bi bi-check2-circle"></i></div><div><div class="erp-stat-label">Paid Amount</div><div class="erp-stat-value">৳ <?php echo e(number_format($summary['paid'],2)); ?></div></div></div>
    <div class="erp-stat-card"><div class="erp-stat-icon orange"><i class="bi bi-hourglass-split"></i></div><div><div class="erp-stat-label">Supplier Due</div><div class="erp-stat-value">৳ <?php echo e(number_format($summary['due'],2)); ?></div></div></div>
</div>

<form class="card erp-filter-card mb-3" method="GET">
    <div class="erp-filter-grid">
        <div><div class="erp-field-label">Search</div><input class="form-control" name="q" value="<?php echo e(request('q')); ?>" placeholder="Purchase no, supplier invoice, supplier..."></div>
        <div><div class="erp-field-label">Supplier</div><select class="form-select" name="supplier_id"><option value="">All Suppliers</option><?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($supplier->id); ?>" <?php if((string)request('supplier_id')===(string)$supplier->id): echo 'selected'; endif; ?>><?php echo e($supplier->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div><div class="erp-field-label">Warehouse</div><select class="form-select" name="warehouse_id"><option value="">All Warehouses</option><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($warehouse->id); ?>" <?php if((string)request('warehouse_id')===(string)$warehouse->id): echo 'selected'; endif; ?>><?php echo e($warehouse->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div><div class="erp-field-label">Status</div><select class="form-select" name="status"><option value="">All Status</option><?php $__currentLoopData = ['draft','posted']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status')===$status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div><div class="erp-field-label">From</div><input type="date" class="form-control" name="from" value="<?php echo e(request('from')); ?>"></div>
        <div><div class="erp-field-label">To</div><input type="date" class="form-control" name="to" value="<?php echo e(request('to')); ?>"></div>
        <div class="d-flex gap-2"><button class="btn btn-primary"><i class="bi bi-funnel me-1"></i> Filter</button><a class="btn btn-light border" href="<?php echo e(route('purchases.index')); ?>" title="Reset"><i class="bi bi-arrow-counterclockwise"></i></a></div>
    </div>
</form>

<div class="card erp-data-card">
    <div class="erp-data-head"><h2 class="erp-data-title">Purchase Register</h2><span class="text-muted" style="font-size:9px"><?php echo e($rows->total()); ?> record(s)</span></div>
    <div class="table-responsive">
        <table class="table erp-table-modern table-hover align-middle">
            <thead><tr><th>Date</th><th>Purchase No.</th><th>Supplier</th><th>Warehouse</th><th>Supplier Invoice</th><th>Status</th><th class="money">Total</th><th class="money">Paid</th><th class="money">Due</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($row->purchase_date->format('d M Y')); ?></td>
                    <td><a class="erp-ref-link" href="<?php echo e(route('purchases.show',$row)); ?>"><?php echo e($row->purchase_no); ?></a></td>
                    <td><div class="fw-semibold"><?php echo e($row->supplier->name); ?></div></td>
                    <td><?php echo e($row->warehouse->name); ?></td>
                    <td><?php echo e($row->supplier_invoice_no ?: '—'); ?></td>
                    <td><span class="erp-status-pill <?php echo e($row->status); ?>"><i class="bi <?php echo e($row->status==='posted'?'bi-check-circle-fill':'bi-clock-fill'); ?>"></i><?php echo e($row->status); ?></span></td>
                    <td class="money fw-semibold">৳ <?php echo e(number_format($row->grand_total,2)); ?></td>
                    <td class="money">৳ <?php echo e(number_format($row->paid_amount,2)); ?></td>
                    <td class="money <?php echo e($row->due_amount > 0 ? 'text-danger' : ''); ?>">৳ <?php echo e(number_format($row->due_amount,2)); ?></td>
                    <td><div class="erp-row-actions">
                        <a class="erp-action-btn" href="<?php echo e(route('purchases.show',$row)); ?>" title="View"><i class="bi bi-eye"></i></a>
                        <?php if($row->status==='draft'): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.edit')): ?><a class="erp-action-btn" href="<?php echo e(route('purchases.edit',$row)); ?>" title="Edit"><i class="bi bi-pencil"></i></a><?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchases.delete')): ?><form method="POST" action="<?php echo e(route('purchases.destroy',$row)); ?>" onsubmit="return confirm('Delete this draft purchase?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="erp-action-btn danger" type="submit" title="Delete"><i class="bi bi-trash"></i></button></form><?php endif; ?>
                        <?php endif; ?>
                    </div></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="10" class="erp-empty-table"><i class="bi bi-inbox fs-4 d-block mb-2"></i>No purchases found for the selected filters.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($rows->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/purchases/index.blade.php ENDPATH**/ ?>