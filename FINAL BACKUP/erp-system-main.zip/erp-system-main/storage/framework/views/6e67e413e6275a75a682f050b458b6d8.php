<?php $__env->startSection('title',$item->exists?'Edit Category':'Add Category'); ?> <?php $__env->startSection('heading',$item->exists?'Edit Category':'Add Category'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e($item->exists ? route('categories.update',$item) : route('categories.store')); ?>"><?php echo csrf_field(); ?> <?php if($item->exists): ?><?php echo method_field('PUT'); ?><?php endif; ?>
<div class="card"><div class="card-body"><div class="row g-3">
<div class="col-md-6"><label class="form-label required">Name</label><input class="form-control" name="name" value="<?php echo e(old('name',$item->name)); ?>" required></div>
<div class="col-md-6"><label class="form-label">Code</label><input class="form-control" name="code" value="<?php echo e(old('code',$item->code)); ?>"></div>
<div class="col-md-6"><label class="form-label">Parent Category</label><select class="form-select" name="parent_id"><option value="">None</option><?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($parent->id); ?>" <?php if(old('parent_id',$item->parent_id)==$parent->id): echo 'selected'; endif; ?>><?php echo e($parent->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
<div class="col-md-6"><label class="form-label">Status</label><select class="form-select" name="is_active"><option value="1" <?php if(old('is_active',$item->exists?$item->is_active:1)==1): echo 'selected'; endif; ?>>Active</option><option value="0" <?php if(old('is_active',$item->exists?$item->is_active:1)==0): echo 'selected'; endif; ?>>Inactive</option></select></div>
<div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description"><?php echo e(old('description',$item->description)); ?></textarea></div>
</div></div><div class="card-footer bg-white"><button class="btn btn-primary">Save</button> <a class="btn btn-outline-secondary" href="<?php echo e(route('categories.index')); ?>">Cancel</a></div></div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/categories/form.blade.php ENDPATH**/ ?>