LARAVEL ERP SAMPLE DATABASE
===========================

This package is made for the Laravel ERP Step 1-14 source code previously provided.

REFERENCE DATE
--------------
2026-08-28

FILES
-----
1. erp_system_sample.sqlite
   Ready SQLite database with schema, authentication/permissions, and sample data.

2. erp_system_sample_data_mysql.sql
   Sample-data add-on for an existing MySQL 'erp_system' database.
   WARNING: It clears existing business/master data before inserting demo data.
   Use only on a development/demo database.

3. erp_system_full_with_sample_data.sql
   Full MySQL database: schema + base seed + sample dashboard data.
   Use this for a fresh demo database.

4. EXPECTED_DASHBOARD_METRICS.txt
   Values that should appear in the current dashboard.

MYSQL FRESH IMPORT
------------------
Create/import with:

  mysql -u root -p < erp_system_full_with_sample_data.sql

or, if your database/schema is already installed:

  mysql -u root -p erp_system < erp_system_sample_data_mysql.sql

SQLITE
------
Set your .env approximately to:

  DB_CONNECTION=sqlite
  DB_DATABASE=/absolute/path/to/erp_system_sample.sqlite

Then run:

  php artisan optimize:clear
  php artisan permission:cache-reset

DEFAULT LOGIN
-------------
Email:    admin@example.com
Username: admin
Password: ChangeMe123!

EXPECTED DASHBOARD VALUES
-------------------------
Today Sales:      28,540.00
Today Purchases:  18,750.00
Month Sales:      685,250.00
Month Expenses:   96,540.00
Receivable:       325,680.00
Payable:          245,450.00
Stock Value:      1,245,300.00
Low Stock Items:  23

ADDITIONAL SAMPLE DATA
----------------------
Customers:  156
Suppliers:  62
Products:   482
Warehouses: 4

Also includes purchases, sales, customer receipts, supplier payments, expenses,
employees, payroll, quotations, sales/purchase returns, stock adjustments,
stock transfers, accounting journal entries, notifications, and activity logs.

IMPORTANT
---------
The current Laravel dashboard UI only renders 8 KPI cards, a recent-month sales
table/trend, recent sales, and notifications. The sample data supports richer KPI
cards and widgets, but matching the previously generated modern dashboard image
also requires updating the Blade dashboard layout/controller to render those
additional charts/widgets.
