<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Purchase;
use App\Models\Supplier;
use App\Models\Warehouse;
use App\Services\Commercial\PurchaseService;
use Illuminate\Http\Request;

class PurchaseController extends Controller
{
    public function __construct(private PurchaseService $service)
    {
    }

    public function index(Request $request)
    {
        $query = Purchase::query()
            ->when($request->filled('q'), function ($query) use ($request) {
                $term = trim((string) $request->q);
                $query->where(function ($q) use ($term) {
                    $q->where('purchase_no', 'like', "%{$term}%")
                        ->orWhere('supplier_invoice_no', 'like', "%{$term}%")
                        ->orWhereHas('supplier', fn ($s) => $s->where('name', 'like', "%{$term}%"));
                });
            })
            ->when($request->filled('from'), fn ($q) => $q->whereDate('purchase_date', '>=', $request->from))
            ->when($request->filled('to'), fn ($q) => $q->whereDate('purchase_date', '<=', $request->to))
            ->when($request->filled('supplier_id'), fn ($q) => $q->where('supplier_id', $request->supplier_id))
            ->when($request->filled('warehouse_id'), fn ($q) => $q->where('warehouse_id', $request->warehouse_id))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->status));

        $summary = [
            'count' => (clone $query)->count(),
            'total' => (float) (clone $query)->sum('grand_total'),
            'paid' => (float) (clone $query)->sum('paid_amount'),
            'due' => (float) (clone $query)->sum('due_amount'),
        ];

        $rows = (clone $query)
            ->with(['supplier', 'warehouse'])
            ->latest('purchase_date')
            ->latest('id')
            ->paginate(20)
            ->withQueryString();

        $suppliers = Supplier::query()->where('is_active', true)->orderBy('name')->get(['id', 'name']);
        $warehouses = Warehouse::query()->where('is_active', true)->orderBy('name')->get(['id', 'name']);

        return view('purchases.index', compact('rows', 'summary', 'suppliers', 'warehouses'));
    }

    public function create()
    {
        return view('purchases.form', $this->lookups() + ['purchase' => null]);
    }

    public function store(Request $request)
    {
        $purchase = $this->service->create($request->validate($this->rules()));

        return redirect()->route('purchases.show', $purchase)->with('success', 'Purchase created successfully.');
    }

    public function show(Purchase $purchase)
    {
        $purchase->load(['supplier', 'warehouse', 'items.product.unit']);

        return view('purchases.show', compact('purchase'));
    }

    public function edit(Purchase $purchase)
    {
        abort_unless($purchase->status === 'draft', 422, 'Posted purchase cannot be edited.');
        $purchase->load(['items.product.unit']);

        return view('purchases.form', $this->lookups() + compact('purchase'));
    }

    public function update(Request $request, Purchase $purchase)
    {
        $purchase = $this->service->update($purchase, $request->validate($this->rules()));

        return redirect()->route('purchases.show', $purchase)->with('success', 'Purchase updated successfully.');
    }

    public function destroy(Purchase $purchase)
    {
        abort_unless($purchase->status === 'draft', 422, 'Posted purchase cannot be deleted.');
        $purchase->delete();

        return redirect()->route('purchases.index')->with('success', 'Purchase deleted.');
    }

    public function post(Purchase $purchase)
    {
        $this->service->post($purchase);

        return back()->with('success', 'Purchase posted to stock, supplier ledger and accounts.');
    }

    private function lookups(): array
    {
        return [
            'suppliers' => Supplier::query()->where('is_active', true)->orderBy('name')->get(),
            'warehouses' => Warehouse::query()->where('is_active', true)->orderBy('name')->get(),
            'products' => Product::query()->with('unit')->where('is_active', true)->orderBy('name')->get(),
        ];
    }

    private function rules(): array
    {
        return [
            'supplier_id' => 'required|exists:suppliers,id',
            'warehouse_id' => 'required|exists:warehouses,id',
            'purchase_date' => 'required|date',
            'due_date' => 'nullable|date|after_or_equal:purchase_date',
            'supplier_invoice_no' => 'nullable|string|max:100',
            'discount' => 'nullable|numeric|min:0',
            'tax' => 'nullable|numeric|min:0',
            'shipping' => 'nullable|numeric|min:0',
            'other_cost' => 'nullable|numeric|min:0',
            'notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|gt:0',
            'items.*.unit_cost' => 'required|numeric|min:0',
            'items.*.discount' => 'nullable|numeric|min:0',
            'items.*.tax' => 'nullable|numeric|min:0',
        ];
    }
}
