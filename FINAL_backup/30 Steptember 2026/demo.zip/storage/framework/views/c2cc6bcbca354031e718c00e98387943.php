<?php $__env->startSection('title', __('Receive Customer Payment')); ?>
<?php $__env->startSection('heading', __('Receive Customer Payment')); ?>

<?php $__env->startSection('content'); ?>
<?php ($isSeller = auth()->user()->hasRole('Seller')); ?>

<?php if($isSeller): ?>
    <div class="alert alert-info border-0 shadow-sm">
        <strong><?php echo e(__('Seller Receipt')); ?></strong> — <?php echo e(__('You can only receive payment against your own posted sales for today.')); ?>

    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('customer-payments.store')); ?>" class="card card-body">
    <?php echo csrf_field(); ?>
    <div class="row g-3">
        <div class="col-md-4">
            <label class="form-label required"><?php echo e(__('Customer')); ?></label>
            <select name="customer_id" class="form-select" required>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>" <?php if(old('customer_id') == $customer->id): echo 'selected'; endif; ?>><?php echo e($customer->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label <?php echo e($isSeller ? 'required' : ''); ?>"><?php echo e($isSeller ? __('Sales Reference') : __('Invoice (optional)')); ?></label>
            <select name="sale_id" class="form-select" <?php echo e($isSeller ? 'required' : ''); ?>>
                <?php if (! ($isSeller)): ?>
                    <option value=""><?php echo e(__('General Receipt / Advance')); ?></option>
                <?php endif; ?>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sale->id); ?>" <?php if(old('sale_id') == $sale->id): echo 'selected'; endif; ?>>
                        <?php echo e($sale->invoice_no); ?> — <?php echo e(__('Due')); ?> <?php echo e(number_format($sale->due_amount, 2)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label required"><?php echo e(__('Cash/Bank Account')); ?></label>
            <select name="account_id" class="form-select" required>
                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($account->id); ?>" <?php if(old('account_id') == $account->id): echo 'selected'; endif; ?>><?php echo e($account->code); ?> - <?php echo e($account->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-3">
            <label class="form-label required"><?php echo e(__('Date')); ?></label>
            <input type="date" name="payment_date" value="<?php echo e(old('payment_date', now()->toDateString())); ?>" class="form-control" <?php if($isSeller): echo 'readonly'; endif; ?> required>
        </div>

        <div class="col-md-3">
            <label class="form-label required"><?php echo e(__('Amount')); ?></label>
            <input type="number" name="amount" value="<?php echo e(old('amount')); ?>" step="0.01" min="0.01" class="form-control" required>
        </div>

        <div class="col-md-3">
            <label class="form-label required"><?php echo e(__('Method')); ?></label>
            <select name="method" class="form-select" required>
                <?php $__currentLoopData = ['cash','bank','cheque','card','mobile_banking']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($method); ?>" <?php if(old('method', 'cash') === $method): echo 'selected'; endif; ?>><?php echo e(__(ucfirst(str_replace('_', ' ', $method)))); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-3">
            <label class="form-label"><?php echo e(__('Reference')); ?></label>
            <input name="reference" value="<?php echo e(old('reference')); ?>" class="form-control">
        </div>

        <div class="col-12">
            <label class="form-label"><?php echo e(__('Notes')); ?></label>
            <textarea name="notes" class="form-control"><?php echo e(old('notes')); ?></textarea>
        </div>
    </div>

    <div class="mt-3"><button class="btn btn-success"><?php echo e(__('Post Receipt')); ?></button></div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\afrintraders\resources\views/customer_payments/form.blade.php ENDPATH**/ ?>