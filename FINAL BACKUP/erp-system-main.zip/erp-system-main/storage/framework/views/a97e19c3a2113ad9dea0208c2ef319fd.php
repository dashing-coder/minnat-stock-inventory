<?php $__env->startSection('title',$product->name); ?> <?php $__env->startSection('heading',$product->name); ?>
<?php $__env->startSection('actions'); ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products.edit')): ?><a class="btn btn-primary" href="<?php echo e(route('products.edit',$product)); ?>">Edit</a><?php endif; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row g-3">
<div class="col-lg-7"><div class="card"><div class="card-body"><div class="row g-3">
<div class="col-md-4"><strong>Code</strong><div><?php echo e($product->code); ?></div></div>
<div class="col-md-4"><strong>SKU</strong><div><?php echo e($product->sku); ?></div></div>
<div class="col-md-4"><strong>Barcode</strong><div><?php echo e($product->barcode ?: '-'); ?></div></div>
<div class="col-md-4"><strong>Category</strong><div><?php echo e($product->category?->name ?: '-'); ?></div></div>
<div class="col-md-4"><strong>Brand</strong><div><?php echo e($product->brand?->name ?: '-'); ?></div></div>
<div class="col-md-4"><strong>Unit</strong><div><?php echo e($product->unit?->name); ?></div></div>
<div class="col-md-4"><strong>Purchase Price</strong><div><?php echo e(number_format((float)$product->purchase_price,2)); ?></div></div>
<div class="col-md-4"><strong>Selling Price</strong><div><?php echo e(number_format((float)$product->selling_price,2)); ?></div></div>
<div class="col-md-4"><strong>Status</strong><div><?php echo e($product->is_active?'Active':'Inactive'); ?></div></div>
</div></div></div></div>
<div class="col-lg-5"><div class="card"><div class="card-header">Warehouse Stock</div><div class="card-body"><table class="table table-sm"><thead><tr><th>Warehouse</th><th class="text-end">Qty</th><th class="text-end">Available</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $product->warehouseStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($s->warehouse->name); ?></td><td class="text-end"><?php echo e(number_format((float)$s->quantity,4)); ?></td><td class="text-end"><?php echo e(number_format($s->available_quantity,4)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3">No stock records.</td></tr><?php endif; ?>
</tbody></table></div></div></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/products/show.blade.php ENDPATH**/ ?>