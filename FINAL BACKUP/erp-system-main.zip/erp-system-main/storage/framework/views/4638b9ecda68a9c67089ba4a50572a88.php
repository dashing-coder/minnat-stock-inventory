<?php $__env->startSection('title',$user->exists?'Edit User':'Add User'); ?> <?php $__env->startSection('heading',$user->exists?'Edit User':'Add User'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e($user->exists ? route('users.update',$user) : route('users.store')); ?>">
<?php echo csrf_field(); ?> <?php if($user->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
<div class="card"><div class="card-body"><div class="row g-3">
<div class="col-md-6"><label class="form-label required">Name</label><input class="form-control" name="name" value="<?php echo e(old('name',$user->name)); ?>" required></div>
<div class="col-md-6"><label class="form-label required">Username</label><input class="form-control" name="username" value="<?php echo e(old('username',$user->username)); ?>" required></div>
<div class="col-md-6"><label class="form-label required">Email</label><input type="email" class="form-control" name="email" value="<?php echo e(old('email',$user->email)); ?>" required></div>
<div class="col-md-6"><label class="form-label">Phone</label><input class="form-control" name="phone" value="<?php echo e(old('phone',$user->phone)); ?>"></div>
<div class="col-md-6"><label class="form-label <?php echo e($user->exists?'':'required'); ?>">Password</label><input type="password" class="form-control" name="password"><div class="form-text"><?php echo e($user->exists?'Leave blank to keep current password.':'Minimum 8 characters.'); ?></div></div>
<div class="col-md-6"><label class="form-label <?php echo e($user->exists?'':'required'); ?>">Confirm Password</label><input type="password" class="form-control" name="password_confirmation"></div>
<div class="col-md-6"><label class="form-label required">Status</label><select class="form-select" name="status"><?php $__currentLoopData = ['active','inactive','suspended']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s); ?>" <?php if(old('status',$user->status?:'active')===$s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
<div class="col-12"><label class="form-label required">Roles</label><div class="row">
<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="col-md-4"><label class="form-check"><input class="form-check-input" type="checkbox" name="roles[]" value="<?php echo e($role->name); ?>" <?php if(in_array($role->name,old('roles',$user->exists?$user->roles->pluck('name')->all():[]))): echo 'checked'; endif; ?>><span class="form-check-label"><?php echo e($role->name); ?></span></label></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div></div></div></div>
<div class="card-footer bg-white"><button class="btn btn-primary">Save</button> <a class="btn btn-outline-secondary" href="<?php echo e(route('users.index')); ?>">Cancel</a></div></div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/users/form.blade.php ENDPATH**/ ?>