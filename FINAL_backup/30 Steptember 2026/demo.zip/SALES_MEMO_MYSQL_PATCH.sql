-- M/S Afrin Traders - Dynamic Sales Memo database patch
-- Target: MySQL / MariaDB
-- Safe to run on an existing Seller-Control ERP database.

START TRANSACTION;

ALTER TABLE `sales`
    ADD COLUMN IF NOT EXISTS `labor_charge` DECIMAL(18,2) NOT NULL DEFAULT 0.00 AFTER `shipping`;

ALTER TABLE `sale_items`
    ADD COLUMN IF NOT EXISTS `bundle_quantity` DECIMAL(18,4) NULL AFTER `quantity`;

INSERT IGNORE INTO `settings` (`key`,`value`,`group`,`type`,`is_public`,`created_at`,`updated_at`) VALUES
('company_name_bn','মেসার্স আফরিন ট্রেডার্স','memo','string',1,NOW(),NOW()),
('company_owner','Shamsul Molla','memo','string',1,NOW(),NOW()),
('company_owner_bn','শামছুল মোল্লা','memo','string',1,NOW(),NOW()),
('company_address_bn','আব্দুল মোল্লা সুপার মার্কেট, বালুচর বাজার, (ডাচ বাংলা ব্যাংকের নিচে) সিরাজদিখান, মুন্সীগঞ্জ','memo','string',1,NOW(),NOW()),
('memo_business_description_en','Dealer and retailer of TMT rod, angle, flat bar, deformed bar, binding wire, chemical, bitumen, cement and construction materials.','memo','string',1,NOW(),NOW()),
('memo_business_description_bn','TMT 400/500/600 গ্রেডের রড, এঙ্গেল, ফ্লাটবার, ডিফর্ম বার, বাইন্ডিং তার, কেমিকেল, বিটুমিন, সিমেন্ট ও নির্মাণ সামগ্রীর পাইকারী ও খুচরা বিক্রেতা।','memo','string',1,NOW(),NOW()),
('memo_footer_en','Digital weighing is available here.','memo','string',1,NOW(),NOW()),
('memo_footer_bn','এখানে ডিজিটাল পদ্ধতিতে ওজন দেওয়া হয়।','memo','string',1,NOW(),NOW());

UPDATE `settings`
SET `value`='M/S Afrin Traders', `updated_at`=NOW()
WHERE `key`='company_name' AND (`value` IS NULL OR `value`='' OR `value` IN ('Laravel ERP','Afrin Traders'));

UPDATE `settings`
SET `value`='01932-223333, 01970-479940, 01916-223333', `updated_at`=NOW()
WHERE `key`='company_phone' AND (`value` IS NULL OR `value`='');

UPDATE `settings`
SET `value`='Abdul Molla Super Market, Baluchar Bazar (under Dutch-Bangla Bank), Sirajdikhan, Munshiganj', `updated_at`=NOW()
WHERE `key`='company_address' AND (`value` IS NULL OR `value`='');

COMMIT;
