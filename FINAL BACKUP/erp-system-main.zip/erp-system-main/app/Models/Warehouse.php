<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Warehouse extends Model
{
    use SoftDeletes;
    protected $fillable = ['code','name','phone','email','address','is_default','is_active'];
    protected function casts(): array { return ['is_default'=>'boolean','is_active'=>'boolean']; }
    public function stocks(): HasMany { return $this->hasMany(WarehouseStock::class); }
    public function stockMovements(): HasMany { return $this->hasMany(StockMovement::class); }
}
