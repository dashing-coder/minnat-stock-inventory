<?php
namespace App\Http\Middleware;
use Closure;use Illuminate\Http\Request;use Illuminate\Support\Facades\Auth;use Symfony\Component\HttpFoundation\Response;
class EnsureActiveUser
{
    public function handle(Request $request, Closure $next): Response
    {
        if($request->user() && $request->user()->status!=='active'){Auth::logout();$request->session()->invalidate();return redirect()->route('login')->withErrors(['login'=>'Your account is inactive.']);}
        return $next($request);
    }
}
