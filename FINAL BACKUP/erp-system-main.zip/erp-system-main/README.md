Laravel ERP - Modern Purchase Module Replacement
=================================================

Compatible with the Step 1-14 Laravel ERP + Modern Dashboard package.

WHAT IT UPGRADES
----------------
- Purchase List: modern KPIs, search, supplier/warehouse/status/date filters, action buttons
- Purchase Create/Edit: responsive invoice-style item entry and live totals
- Purchase View: professional document layout and print-friendly summary
- Purchase Return List/Create/Edit/View: matching modern UI
- PurchaseController and PurchaseReturnController: richer filtering/lookups
- Fixes draft purchase edit tax presentation so item tax is not double-counted on re-save

INSTALL
-------
1. Back up your project.
2. Copy the folders from this ZIP into your Laravel project root and overwrite matching files.
3. Run:

   php artisan optimize:clear
   php artisan permission:cache-reset

4. Hard refresh the browser: Ctrl+F5

No database migration is required.
