<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Setting extends Model
{
    protected $fillable=['key','value','group','type','is_public'];
    protected function casts(): array{return ['is_public'=>'boolean'];}
}
