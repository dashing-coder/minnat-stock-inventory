<?php $__env->startSection('title',$customer->name); ?> <?php $__env->startSection('heading',$customer->name); ?>
<?php $__env->startSection('actions'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customers.ledger')): ?><a class="btn btn-outline-primary" href="<?php echo e(route('customers.ledger',$customer)); ?>">Ledger</a><?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customers.edit')): ?><a class="btn btn-primary" href="<?php echo e(route('customers.edit',$customer)); ?>">Edit</a><?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body"><div class="row g-3">
<div class="col-md-4"><strong>Code</strong><div><?php echo e($customer->code); ?></div></div>
<div class="col-md-4"><strong>Group</strong><div><?php echo e($customer->group?->name ?: '-'); ?></div></div>
<div class="col-md-4"><strong>Status</strong><div><?php echo e($customer->is_active?'Active':'Inactive'); ?></div></div>
<div class="col-md-4"><strong>Phone</strong><div><?php echo e($customer->phone ?: '-'); ?></div></div>
<div class="col-md-4"><strong>Email</strong><div><?php echo e($customer->email ?: '-'); ?></div></div>
<div class="col-md-4"><strong>Company</strong><div><?php echo e($customer->company_name ?: '-'); ?></div></div>
<div class="col-12"><strong>Address</strong><div><?php echo e($customer->address ?: '-'); ?></div></div>
</div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/customers/show.blade.php ENDPATH**/ ?>