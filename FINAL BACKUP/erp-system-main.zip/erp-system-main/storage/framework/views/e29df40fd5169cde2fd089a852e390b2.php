<?php $__env->startSection('title', $payroll->payroll_no); ?>
<?php $__env->startSection('heading', 'Payroll ' . $payroll->payroll_no . ' - ' . $payroll->period); ?>

<?php $__env->startSection('actions'); ?>
    <?php if($payroll->status === 'draft'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payroll.post')): ?>
            <form class="d-inline" method="POST" action="<?php echo e(route('payrolls.post', $payroll)); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-success">Post Payroll</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?><form method="POST" action="<?php echo e(route('payrolls.update',$payroll)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?><div class="card"><table class="table mb-0"><thead><tr><th>Employee</th><th class="money">Basic</th><th class="money">Allowance</th><th>Bonus</th><th>Overtime</th><th>Deduction</th><th class="money">Net</th><th class="money">Paid</th></tr></thead><tbody><?php $__currentLoopData = $payroll->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($i->employee->name); ?></td><td class="money"><?php echo e(number_format($i->basic_salary,2)); ?></td><td class="money"><?php echo e(number_format($i->allowance,2)); ?></td><td><input class="form-control form-control-sm" type="number" step="0.01" min="0" name="items[<?php echo e($i->id); ?>][bonus]" value="<?php echo e($i->bonus); ?>" <?php if($payroll->status!=='draft'): echo 'disabled'; endif; ?>></td><td><input class="form-control form-control-sm" type="number" step="0.01" min="0" name="items[<?php echo e($i->id); ?>][overtime]" value="<?php echo e($i->overtime); ?>" <?php if($payroll->status!=='draft'): echo 'disabled'; endif; ?>></td><td><input class="form-control form-control-sm" type="number" step="0.01" min="0" name="items[<?php echo e($i->id); ?>][deduction]" value="<?php echo e($i->deduction); ?>" <?php if($payroll->status!=='draft'): echo 'disabled'; endif; ?>></td><td class="money"><?php echo e(number_format($i->net_salary,2)); ?></td><td class="money"><?php echo e(number_format($i->paid_amount,2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody><tfoot><tr><th colspan="6" class="text-end">Net Total</th><th class="money"><?php echo e(number_format($payroll->net_total,2)); ?></th><th></th></tr></tfoot></table></div><?php if($payroll->status==='draft'): ?><div class="mt-3"><button class="btn btn-primary">Recalculate</button></div><?php endif; ?></form><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/payrolls/show.blade.php ENDPATH**/ ?>