@extends('layouts.app')
@section('title', $saleReturn->return_no)
@section('heading', 'Sales Return ' . $saleReturn->return_no)

@section('actions')
    @if ($saleReturn->status === 'draft')
        @can('sale_returns.edit')
            <a href="{{ route('sale-returns.edit', $saleReturn) }}" class="btn btn-outline-primary">Edit</a>
        @endcan
        @can('sale_returns.post')
            <form class="d-inline" method="POST" action="{{ route('sale-returns.post', $saleReturn) }}">
                @csrf
                <button class="btn btn-success">Post Return</button>
            </form>
        @endcan
    @endif
@endsection
@section('content')<div class="card card-body"><p><b>Customer:</b> {{ $saleReturn->customer?->name ?? 'Walk-in' }} &nbsp; <b>Warehouse:</b> {{ $saleReturn->warehouse->name }} &nbsp; <b>Status:</b> {{ $saleReturn->status }}</p><table class="table"><thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>@foreach($saleReturn->items as $i)<tr><td>{{ $i->product->name }}</td><td>{{ $i->quantity }}</td><td>{{ number_format($i->unit_price,4) }}</td><td>{{ number_format($i->line_total,2) }}</td></tr>@endforeach</tbody></table><div class="text-end fs-5">Grand Total: {{ number_format($saleReturn->grand_total,2) }}</div></div>@endsection
