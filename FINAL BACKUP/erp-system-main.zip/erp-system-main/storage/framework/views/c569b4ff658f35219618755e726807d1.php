<?php $__env->startSection('title', $quotation->quotation_no); ?>
<?php $__env->startSection('heading', 'Quotation ' . $quotation->quotation_no); ?>

<?php $__env->startSection('actions'); ?>
    <?php if(in_array($quotation->status, ['draft', 'sent'], true)): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotations.edit')): ?>
            <a href="<?php echo e(route('quotations.edit', $quotation)); ?>" class="btn btn-outline-primary">
                Edit
            </a>
        <?php endif; ?>
    <?php endif; ?>

    <button type="button" onclick="window.print()" class="btn btn-outline-secondary">
        Print
    </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-body">
        <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap">
            <div>
                <div><strong>Customer:</strong> <?php echo e($quotation->customer?->name ?? 'Walk-in'); ?></div>
                <div><strong>Date:</strong> <?php echo e($quotation->quotation_date?->format('Y-m-d')); ?></div>
                <div><strong>Valid Until:</strong> <?php echo e($quotation->valid_until?->format('Y-m-d') ?? '—'); ?></div>
            </div>

            <div class="no-print">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotations.edit')): ?>
                    <form method="POST" action="<?php echo e(route('quotations.status', $quotation)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <label for="quotation-status" class="form-label mb-1">Status</label>
                        <select
                            id="quotation-status"
                            name="status"
                            class="form-select"
                            onchange="this.form.submit()"
                        >
                            <?php $__currentLoopData = ['draft', 'sent', 'accepted', 'rejected', 'expired']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>" <?php if($quotation->status === $status): echo 'selected'; endif; ?>>
                                    <?php echo e(ucfirst($status)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </form>
                <?php else: ?>
                    <span class="badge bg-secondary">
                        <?php echo e(ucfirst($quotation->status)); ?>

                    </span>
                <?php endif; ?>
            </div>
        </div>

        <hr>

        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th class="text-end">Qty</th>
                        <th class="text-end">Price</th>
                        <th class="text-end">Discount</th>
                        <th class="text-end">Tax</th>
                        <th class="text-end">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $quotation->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->product?->name ?? 'Deleted product'); ?></td>
                            <td class="text-end"><?php echo e(number_format((float) $item->quantity, 4)); ?></td>
                            <td class="text-end"><?php echo e(number_format((float) $item->unit_price, 4)); ?></td>
                            <td class="text-end"><?php echo e(number_format((float) $item->discount, 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format((float) $item->tax, 2)); ?></td>
                            <td class="text-end"><?php echo e(number_format((float) $item->line_total, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">
                                No quotation items found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="row justify-content-end mt-3">
            <div class="col-md-5 col-lg-4">
                <div class="d-flex justify-content-between py-1">
                    <span>Subtotal</span>
                    <strong><?php echo e(number_format((float) $quotation->subtotal, 2)); ?></strong>
                </div>
                <div class="d-flex justify-content-between py-1">
                    <span>Discount</span>
                    <strong><?php echo e(number_format((float) $quotation->discount, 2)); ?></strong>
                </div>
                <div class="d-flex justify-content-between py-1">
                    <span>Tax</span>
                    <strong><?php echo e(number_format((float) $quotation->tax, 2)); ?></strong>
                </div>
                <hr class="my-2">
                <div class="d-flex justify-content-between fs-5">
                    <span>Grand Total</span>
                    <strong><?php echo e(number_format((float) $quotation->grand_total, 2)); ?></strong>
                </div>
            </div>
        </div>

        <?php if($quotation->notes): ?>
            <hr>
            <div>
                <strong>Notes:</strong>
                <div class="text-muted mt-1"><?php echo e($quotation->notes); ?></div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/quotations/show.blade.php ENDPATH**/ ?>