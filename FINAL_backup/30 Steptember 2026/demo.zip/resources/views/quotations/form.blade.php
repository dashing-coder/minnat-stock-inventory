@extends('layouts.app')
@php
    $editing = isset($quotation);
    $productOptions = $products->map(fn ($product) => [
        'id' => $product->id,
        'name' => $product->name,
        'price' => (float) $product->selling_price,
    ])->values()->all();

    $initialItems = old(
        'items',
        $editing
            ? $quotation->items->map(fn ($item) => [
                'product_id' => $item->product_id,
                'quantity' => (float) $item->quantity,
                'unit_price' => (float) $item->unit_price,
                'discount' => (float) $item->discount,
                'tax' => (float) $item->tax,
            ])->values()->all()
            : []
    );
@endphp
@section('title',$editing ? __('Edit Quotation') : __('New Quotation'))
@section('heading',$editing ? __('Edit Quotation') : __('New Quotation'))
@section('content')
<form method="POST" action="{{ $editing ? route('quotations.update',$quotation) : route('quotations.store') }}" class="card card-body">@csrf @if($editing) @method('PUT') @endif
    <div class="row g-3">
        <div class="col-md-4"><label>{{ __('Customer') }}</label><select name="customer_id" class="form-select">
                <option value="">{{ __('Walk-in') }}</option>@foreach($customers as $c)<option value="{{ $c->id }}" @selected(old('customer_id',$quotation->customer_id ?? '')==$c->id)>{{ $c->name }}</option>@endforeach
            </select></div>
        <div class="col-md-4"><label>{{ __('Date') }}</label><input type="date" name="quotation_date" value="{{ old('quotation_date',isset($quotation)?$quotation->quotation_date->toDateString():now()->toDateString()) }}" class="form-control"></div>
        <div class="col-md-4"><label>{{ __('Valid Until') }}</label><input type="date" name="valid_until" value="{{ old('valid_until',isset($quotation)&&$quotation->valid_until?$quotation->valid_until->toDateString():now()->addDays(15)->toDateString()) }}" class="form-control"></div>
    </div>
    <hr>
    <div class="table-responsive">
        <table class="table" id="qt">
            <thead>
                <tr>
                    <th>{{ __('Product') }}</th>
                    <th>{{ __('Qty') }}</th>
                    <th>{{ __('Price') }}</th>
                    <th>{{ __('Discount') }}</th>
                    <th>{{ __('Tax') }}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div><button type="button" id="add" class="btn btn-sm btn-outline-primary align-self-start">{{ __('Add Item') }}</button>
    <div class="row g-3 mt-2">
        <div class="col-md-3"><label>{{ __('Invoice Discount') }}</label><input name="discount" type="number" min="0" step="0.01" value="{{ old('discount',$quotation->discount ?? 0) }}" class="form-control"></div>
        <div class="col-md-3"><label>{{ __('Invoice Tax') }}</label><input name="tax" type="number" min="0" step="0.01" value="{{ old('tax',$quotation->tax ?? 0) }}" class="form-control"></div>
        <div class="col"><label>{{ __('Notes') }}</label><input name="notes" value="{{ old('notes',$quotation->notes ?? '') }}" class="form-control"></div>
    </div>
    <div class="mt-3"><button class="btn btn-primary">{{ $editing ? 'Update Quotation' : 'Save Quotation' }}</button></div>
</form>
@endsection
@push('scripts')<script>
    const p = @json($productOptions);
    const initial = @json($initialItems);
    let i = 0;

    function add(row = {}) {
        let tr = document.createElement('tr');
        tr.innerHTML = `<td><select class="form-select prod" name="items[${i}][product_id]" required><option value="">{{ __('Select') }}</option>${p.map(x=>`<option value="${x.id}" ${String(x.id)===String(row.product_id||'')?'selected':''}>${x.name}</option>`).join('')}</select></td><td><input class="form-control" name="items[${i}][quantity]" type="number" step="0.0001" min="0.0001" value="${row.quantity??1}"></td><td><input class="form-control price" name="items[${i}][unit_price]" type="number" step="0.0001" min="0" value="${row.unit_price??0}"></td><td><input class="form-control" name="items[${i}][discount]" type="number" step="0.01" min="0" value="${row.discount??0}"></td><td><input class="form-control" name="items[${i}][tax]" type="number" step="0.01" min="0" value="${row.tax??0}"></td><td><button type="button" class="btn btn-outline-danger btn-sm">×</button></td>`;
        tr.querySelector('.prod').onchange = e => {
            let x = p.find(y => String(y.id) === e.target.value);
            if (x && !row.unit_price) tr.querySelector('.price').value = x.price
        };
        tr.querySelector('button').onclick = () => tr.remove();
        document.querySelector('#qt tbody').appendChild(tr);
        i++
    }
    document.getElementById('add').onclick = () => add();
    (initial.length ? initial : [{}]).forEach(add);
</script>@endpush
