@extends('layouts.app')

@php
    $editing = (bool) $purchase;

    /*
     * Prepare JavaScript data before @json.
     * Keeping arrow functions / nested arrays out of the @json directive prevents
     * Blade's directive parser from prematurely closing the expression.
     */
    $productOptions = $products
        ->map(fn ($product) => [
            'id'    => $product->id,
            'name'  => $product->name,
            'price' => (float) $product->purchase_price,
        ])
        ->values()
        ->all();

    $existingItems = old('items');

    if ($existingItems === null) {
        $existingItems = $purchase?->items
            ?->map(fn ($item) => [
                'product_id' => $item->product_id,
                'quantity'   => (float) $item->quantity,
                'unit_cost'  => (float) $item->unit_cost,
                'discount'   => (float) $item->discount,
                'tax'        => (float) $item->tax,
            ])
            ->values()
            ->all() ?? [];
    }
@endphp

@section('title', $editing ? __('Edit Purchase') : __('New Purchase'))
@section('heading', $editing ? __('Edit Purchase') : __('New Purchase'))

@section('content')
<form
    method="POST"
    action="{{ $editing ? route('purchases.update', $purchase) : route('purchases.store') }}"
    class="card card-body"
>
    @csrf
    @if($editing)
        @method('PUT')
    @endif

    <div class="row g-3">
        <div class="col-md-4">
            <label class="form-label required">{{ __('Supplier') }}</label>
            <select name="supplier_id" class="form-select" required>
                <option value="">{{ __('Select') }}</option>
                @foreach($suppliers as $supplier)
                    <option
                        value="{{ $supplier->id }}"
                        @selected(old('supplier_id', $purchase?->supplier_id) == $supplier->id)
                    >
                        {{ $supplier->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label required">{{ __('Warehouse') }}</label>
            <select name="warehouse_id" class="form-select" required>
                @foreach($warehouses as $warehouse)
                    <option
                        value="{{ $warehouse->id }}"
                        @selected(old('warehouse_id', $purchase?->warehouse_id) == $warehouse->id)
                    >
                        {{ $warehouse->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="col-md-2">
            <label class="form-label required">{{ __('Purchase Date') }}</label>
            <input
                type="date"
                name="purchase_date"
                value="{{ old('purchase_date', $purchase?->purchase_date?->format('Y-m-d') ?? now()->toDateString()) }}"
                class="form-control"
                required
            >
        </div>

        <div class="col-md-2">
            <label class="form-label">{{ __('Due Date') }}</label>
            <input
                type="date"
                name="due_date"
                value="{{ old('due_date', $purchase?->due_date?->format('Y-m-d')) }}"
                class="form-control"
            >
        </div>

        <div class="col-md-4">
            <label class="form-label">{{ __('Supplier Invoice') }}</label>
            <input
                name="supplier_invoice_no"
                value="{{ old('supplier_invoice_no', $purchase?->supplier_invoice_no) }}"
                class="form-control"
            >
        </div>
    </div>

    <hr>

    <div class="d-flex justify-content-between align-items-center">
        <h5 class="mb-0">{{ __('Items') }}</h5>
        <button type="button" id="add-item" class="btn btn-sm btn-outline-primary">{{ __('Add Item') }}</button>
    </div>

    <div class="table-responsive mt-2">
        <table class="table form-table" id="items-table">
            <thead>
                <tr>
                    <th>{{ __('Product') }}</th>
                    <th>{{ __('Qty') }}</th>
                    <th>{{ __('Unit Cost') }}</th>
                    <th>{{ __('Discount') }}</th>
                    <th>{{ __('Tax') }}</th>
                    <th></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <div class="row g-3">
        <div class="col-md-2">
            <label class="form-label">{{ __('Invoice Discount') }}</label>
            <input
                name="discount"
                type="number"
                step="0.01"
                min="0"
                value="{{ old('discount', $purchase?->discount ?? 0) }}"
                class="form-control"
            >
        </div>

        <div class="col-md-2">
            <label class="form-label">{{ __('Invoice Tax') }}</label>
            <input
                name="tax"
                type="number"
                step="0.01"
                min="0"
                value="{{ old('tax', 0) }}"
                class="form-control"
            >
        </div>

        <div class="col-md-2">
            <label class="form-label">{{ __('Shipping') }}</label>
            <input
                name="shipping"
                type="number"
                step="0.01"
                min="0"
                value="{{ old('shipping', $purchase?->shipping ?? 0) }}"
                class="form-control"
            >
        </div>

        <div class="col-md-2">
            <label class="form-label">{{ __('Other Cost') }}</label>
            <input
                name="other_cost"
                type="number"
                step="0.01"
                min="0"
                value="{{ old('other_cost', $purchase?->other_cost ?? 0) }}"
                class="form-control"
            >
        </div>

        <div class="col-md-4">
            <label class="form-label">{{ __('Notes') }}</label>
            <input
                name="notes"
                value="{{ old('notes', $purchase?->notes) }}"
                class="form-control"
            >
        </div>
    </div>

    <div class="mt-3">
        <button class="btn btn-primary">{{ __('Save Draft') }}</button>
        <a href="{{ route('purchases.index') }}" class="btn btn-light">{{ __('Cancel') }}</a>
    </div>
</form>
@endsection

@push('scripts')
<script>
    const products = @json($productOptions);
    const existing = @json($existingItems);
    let idx = 0;

    function row(data = {}) {
        const opts = products.map(product => `
            <option value="${product.id}" ${String(data.product_id) === String(product.id) ? 'selected' : ''}>
                ${product.name}
            </option>
        `).join('');

        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td>
                <select class="form-select product" name="items[${idx}][product_id]" required>
                    <option value="">{{ __('Select') }}</option>
                    ${opts}
                </select>
            </td>
            <td>
                <input class="form-control" type="number" step="0.0001" min="0.0001"
                       name="items[${idx}][quantity]" value="${data.quantity ?? 1}" required>
            </td>
            <td>
                <input class="form-control cost" type="number" step="0.0001" min="0"
                       name="items[${idx}][unit_cost]" value="${data.unit_cost ?? 0}" required>
            </td>
            <td>
                <input class="form-control" type="number" step="0.01" min="0"
                       name="items[${idx}][discount]" value="${data.discount ?? 0}">
            </td>
            <td>
                <input class="form-control" type="number" step="0.01" min="0"
                       name="items[${idx}][tax]" value="${data.tax ?? 0}">
            </td>
            <td>
                <button type="button" class="btn btn-sm btn-outline-danger remove" aria-label="Remove item">×</button>
            </td>
        `;

        tr.querySelector('.product').addEventListener('change', event => {
            const selectedProduct = products.find(product => String(product.id) === event.target.value);

            if (selectedProduct) {
                tr.querySelector('.cost').value = selectedProduct.price;
            }
        });

        tr.querySelector('.remove').addEventListener('click', () => tr.remove());
        document.querySelector('#items-table tbody').appendChild(tr);
        idx++;
    }

    document.getElementById('add-item').addEventListener('click', () => row());
    (existing.length ? existing : [{}]).forEach(row);
</script>
@endpush
