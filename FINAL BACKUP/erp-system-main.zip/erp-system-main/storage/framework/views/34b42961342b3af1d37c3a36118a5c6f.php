<?php $__env->startSection('title',$customer->exists?'Edit Customer':'Add Customer'); ?> <?php $__env->startSection('heading',$customer->exists?'Edit Customer':'Add Customer'); ?>
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e($customer->exists ? route('customers.update',$customer) : route('customers.store')); ?>"><?php echo csrf_field(); ?> <?php if($customer->exists): ?><?php echo method_field('PUT'); ?><?php endif; ?>
<div class="card mb-3"><div class="card-header">Basic Information</div><div class="card-body"><div class="row g-3">
<div class="col-md-6"><label class="form-label required">Customer Name</label><input class="form-control" name="name" value="<?php echo e(old('name',$customer->name)); ?>" required></div>
<div class="col-md-6"><label class="form-label">Group</label><select class="form-select" name="customer_group_id"><option value="">None</option><?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($g->id); ?>" <?php if(old('customer_group_id',$customer->customer_group_id)==$g->id): echo 'selected'; endif; ?>><?php echo e($g->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
<div class="col-md-6"><label class="form-label">Company</label><input class="form-control" name="company_name" value="<?php echo e(old('company_name',$customer->company_name)); ?>"></div>
<div class="col-md-6"><label class="form-label">Contact Person</label><input class="form-control" name="contact_person" value="<?php echo e(old('contact_person',$customer->contact_person)); ?>"></div>
<div class="col-md-6"><label class="form-label">Phone</label><input class="form-control" name="phone" value="<?php echo e(old('phone',$customer->phone)); ?>"></div>
<div class="col-md-6"><label class="form-label">Alternate Phone</label><input class="form-control" name="alternate_phone" value="<?php echo e(old('alternate_phone',$customer->alternate_phone)); ?>"></div>
<div class="col-md-6"><label class="form-label">Email</label><input class="form-control" type="email" name="email" value="<?php echo e(old('email',$customer->email)); ?>"></div>
<div class="col-md-6"><label class="form-label">Tax Number</label><input class="form-control" name="tax_number" value="<?php echo e(old('tax_number',$customer->tax_number)); ?>"></div>
<div class="col-12"><label class="form-label">Address</label><textarea class="form-control" name="address"><?php echo e(old('address',$customer->address)); ?></textarea></div>
<div class="col-md-4"><label class="form-label">City</label><input class="form-control" name="city" value="<?php echo e(old('city',$customer->city)); ?>"></div>
<div class="col-md-4"><label class="form-label">District</label><input class="form-control" name="district" value="<?php echo e(old('district',$customer->district)); ?>"></div>
<div class="col-md-4"><label class="form-label">Country</label><input class="form-control" name="country" value="<?php echo e(old('country',$customer->country)); ?>"></div>
</div></div></div>
<div class="card mb-3"><div class="card-header">Credit & Status</div><div class="card-body"><div class="row g-3">
<?php if(!$customer->exists): ?>
<div class="col-md-4"><label class="form-label">Opening Balance</label><input class="form-control" type="number" step=".01" min="0" name="opening_balance" value="<?php echo e(old('opening_balance',0)); ?>"></div>
<div class="col-md-4"><label class="form-label">Opening Balance Type</label><select class="form-select" name="opening_balance_type"><option value="receivable" <?php if(old('opening_balance_type')==='receivable'): echo 'selected'; endif; ?>>Receivable</option><option value="advance" <?php if(old('opening_balance_type')==='advance'): echo 'selected'; endif; ?>>Advance</option></select></div>
<?php endif; ?>
<div class="col-md-4"><label class="form-label">Credit Limit</label><input class="form-control" type="number" step=".01" min="0" name="credit_limit" value="<?php echo e(old('credit_limit',$customer->credit_limit)); ?>"></div>
<div class="col-md-4"><label class="form-label">Payment Terms (Days)</label><input class="form-control" type="number" min="0" name="payment_terms_days" value="<?php echo e(old('payment_terms_days',$customer->payment_terms_days??0)); ?>"></div>
<div class="col-md-4"><label class="form-label">Status</label><select class="form-select" name="is_active"><option value="1" <?php if(old('is_active',$customer->exists?$customer->is_active:1)==1): echo 'selected'; endif; ?>>Active</option><option value="0" <?php if(old('is_active',$customer->exists?$customer->is_active:1)==0): echo 'selected'; endif; ?>>Inactive</option></select></div>
<div class="col-12"><label class="form-label">Notes</label><textarea class="form-control" name="notes"><?php echo e(old('notes',$customer->notes)); ?></textarea></div>
</div></div></div>
<button class="btn btn-primary">Save Customer</button> <a class="btn btn-outline-secondary" href="<?php echo e(route('customers.index')); ?>">Cancel</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/customers/form.blade.php ENDPATH**/ ?>