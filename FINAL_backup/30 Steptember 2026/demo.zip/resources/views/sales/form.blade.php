@extends('layouts.app')

@php
    $editing = (bool) $sale;

    $productOptions = $products
        ->map(fn ($product) => [
            'id'    => $product->id,
            'name'  => $product->name,
            'price' => (float) $product->selling_price,
        ])
        ->values()
        ->all();

    $existingItems = old('items');

    if ($existingItems === null) {
        $existingItems = $sale?->items
            ?->map(fn ($item) => [
                'product_id'      => $item->product_id,
                'quantity'        => (float) $item->quantity,
                'bundle_quantity' => $item->bundle_quantity !== null ? (float) $item->bundle_quantity : null,
                'unit_price'      => (float) $item->unit_price,
                'discount_type'   => $item->discount_type ?: 'fixed',
                'discount_value'  => $item->discount_value !== null ? (float) $item->discount_value : (float) $item->discount,
                'discount'        => (float) $item->discount,
                'tax'             => (float) $item->tax,
            ])
            ->values()
            ->all() ?? [];
    }

    $discountLabels = [
        'select' => __('Select'),
        'fixed' => __('Fixed Amount'),
        'percentage' => __('Percentage'),
        'fixedError' => __('Fixed discount cannot exceed product subtotal.'),
        'percentageError' => __('Percentage discount cannot exceed 100%.'),
    ];
@endphp

@section('title', $editing ? __('Edit Sale') : __('New Sale'))
@section('heading', $editing ? __('Edit Sale') : __('New Sale'))

@section('content')
<form
    method="POST"
    action="{{ $editing ? route('sales.update', $sale) : route('sales.store') }}"
    class="card card-body"
    id="sale-form"
>
    @csrf
    @if($editing)
        @method('PUT')
    @endif

    <div class="row g-3">
        <div class="col-md-4">
            <label class="form-label">{{ __('Customer') }}</label>
            <select name="customer_id" class="form-select">
                <option value="">{{ __('Walk-in Customer') }}</option>
                @foreach($customers as $customer)
                    <option
                        value="{{ $customer->id }}"
                        @selected(old('customer_id', $sale?->customer_id) == $customer->id)
                    >
                        {{ $customer->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label required">{{ __('Warehouse') }}</label>
            <select name="warehouse_id" class="form-select" required>
                @foreach($warehouses as $warehouse)
                    <option
                        value="{{ $warehouse->id }}"
                        @selected(old('warehouse_id', $sale?->warehouse_id) == $warehouse->id)
                    >
                        {{ $warehouse->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="col-md-2">
            <label class="form-label required">{{ __('Sale Date') }}</label>
            <input
                type="date"
                name="sale_date"
                value="{{ old('sale_date', $sale?->sale_date?->format('Y-m-d') ?? now()->toDateString()) }}"
                class="form-control"
                @readonly(auth()->user()->hasRole('Seller'))
                required
            >
        </div>

        <div class="col-md-2">
            <label class="form-label">{{ __('Due Date') }}</label>
            <input
                type="date"
                name="due_date"
                value="{{ old('due_date', $sale?->due_date?->format('Y-m-d')) }}"
                class="form-control"
            >
        </div>
    </div>

    <hr>

    <div class="d-flex justify-content-between align-items-center">
        <h5 class="mb-0">{{ __('Items') }}</h5>
        <button type="button" id="add-item" class="btn btn-sm btn-outline-primary">{{ __('Add Item') }}</button>
    </div>

    <div class="table-responsive mt-2">
        <table class="table form-table align-middle" id="items-table">
            <thead>
                <tr>
                    <th style="min-width:210px">{{ __('Product') }}</th>
                    <th style="min-width:100px">{{ __('Qty') }}</th>
                    <th style="min-width:110px">{{ __('Bag / Bundle') }}</th>
                    <th style="min-width:110px">{{ __('Unit Price') }}</th>
                    <th style="min-width:135px">{{ __('Discount Type') }}</th>
                    <th style="min-width:120px">{{ __('Discount Value') }}</th>
                    <th style="min-width:120px">{{ __('Discount Amount') }}</th>
                    <th style="min-width:100px">{{ __('Tax') }}</th>
                    <th style="min-width:125px">{{ __('Final Subtotal') }}</th>
                    <th style="width:50px"></th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

    <div class="row g-3 mt-1">
        <div class="col-lg-8">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">{{ __('Invoice Discount (Fixed)') }}</label>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="discount"
                        value="{{ old('discount', $sale?->discount ?? 0) }}"
                        class="form-control invoice-calc"
                    >
                </div>

                <div class="col-md-3">
                    <label class="form-label">{{ __('Invoice Tax') }}</label>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="tax"
                        value="{{ old('tax', $sale?->tax ?? 0) }}"
                        class="form-control invoice-calc"
                    >
                </div>

                <div class="col-md-3">
                    <label class="form-label">{{ __('Transport Charge') }}</label>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="shipping"
                        value="{{ old('shipping', $sale?->shipping ?? 0) }}"
                        class="form-control invoice-calc"
                    >
                </div>

                <div class="col-md-3">
                    <label class="form-label">{{ __('Labor Charge') }}</label>
                    <input
                        type="number"
                        step="0.01"
                        min="0"
                        name="labor_charge"
                        value="{{ old('labor_charge', $sale?->labor_charge ?? 0) }}"
                        class="form-control invoice-calc"
                    >
                </div>

                <div class="col-md-12">
                    <label class="form-label">{{ __('Notes') }}</label>
                    <input
                        name="notes"
                        value="{{ old('notes', $sale?->notes) }}"
                        class="form-control"
                    >
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="border rounded-3 p-3 bg-light h-100">
                <div class="d-flex justify-content-between mb-2">
                    <span>{{ __('Subtotal Before Discount') }}</span>
                    <strong id="summary-base">0.00</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>{{ __('Item Discount') }}</span>
                    <strong id="summary-discount">0.00</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>{{ __('Subtotal After Discount') }}</span>
                    <strong id="summary-after-discount">0.00</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>{{ __('Item Tax') }}</span>
                    <strong id="summary-item-tax">0.00</strong>
                </div>
                <hr class="my-2">
                <div class="d-flex justify-content-between fs-6">
                    <strong>{{ __('Invoice Total Preview') }}</strong>
                    <strong id="summary-grand">0.00</strong>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-3">
        <button class="btn btn-primary" id="save-sale">{{ __('Save Draft') }}</button>
    </div>
</form>
@endsection

@push('scripts')
<script>
const products = @json($productOptions);
const existing = @json($existingItems);
const discountLabels = @json($discountLabels);
let idx = 0;

function numberValue(value) {
    const number = Number.parseFloat(value);
    return Number.isFinite(number) ? number : 0;
}

function money(value) {
    return numberValue(value).toFixed(2);
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function recalculateSummary() {
    let base = 0;
    let discount = 0;
    let afterDiscount = 0;
    let itemTax = 0;

    document.querySelectorAll('#items-table tbody tr').forEach(tr => {
        base += numberValue(tr.dataset.base);
        discount += numberValue(tr.dataset.discount);
        afterDiscount += numberValue(tr.dataset.afterDiscount);
        itemTax += numberValue(tr.dataset.tax);
    });

    const invoiceDiscount = numberValue(document.querySelector('[name="discount"]')?.value);
    const invoiceTax = numberValue(document.querySelector('[name="tax"]')?.value);
    const shipping = numberValue(document.querySelector('[name="shipping"]')?.value);
    const labor = numberValue(document.querySelector('[name="labor_charge"]')?.value);
    const grand = Math.max(0, afterDiscount - invoiceDiscount + itemTax + invoiceTax + shipping + labor);

    document.getElementById('summary-base').textContent = money(base);
    document.getElementById('summary-discount').textContent = money(discount);
    document.getElementById('summary-after-discount').textContent = money(afterDiscount);
    document.getElementById('summary-item-tax').textContent = money(itemTax);
    document.getElementById('summary-grand').textContent = money(grand);

    const hasInvalidDiscount = Boolean(document.querySelector('.discount-value.is-invalid'));
    document.getElementById('save-sale').disabled = hasInvalidDiscount;
}

function recalculateRow(tr) {
    const quantity = numberValue(tr.querySelector('.qty').value);
    const price = numberValue(tr.querySelector('.price').value);
    const discountType = tr.querySelector('.discount-type').value;
    const discountValueInput = tr.querySelector('.discount-value');
    const discountValue = numberValue(discountValueInput.value);
    const tax = numberValue(tr.querySelector('.tax').value);
    const base = quantity * price;

    let discountAmount = 0;
    let error = '';

    if (discountType === 'percentage') {
        discountValueInput.max = '100';
        discountValueInput.placeholder = '%';

        if (discountValue > 100) {
            error = discountLabels.percentageError;
        } else {
            discountAmount = base * discountValue / 100;
        }
    } else {
        discountValueInput.removeAttribute('max');
        discountValueInput.placeholder = '0.00';
        discountAmount = discountValue;

        if (discountAmount > base + 0.000001) {
            error = discountLabels.fixedError;
        }
    }

    if (error) {
        discountValueInput.classList.add('is-invalid');
        tr.querySelector('.discount-error').textContent = error;
    } else {
        discountValueInput.classList.remove('is-invalid');
        tr.querySelector('.discount-error').textContent = '';
    }

    discountAmount = Math.min(Math.max(discountAmount, 0), Math.max(base, 0));
    const finalSubtotal = Math.max(0, base - discountAmount);

    tr.querySelector('.discount-amount').value = money(discountAmount);
    tr.querySelector('.line-subtotal').value = money(finalSubtotal);

    tr.dataset.base = String(base);
    tr.dataset.discount = String(discountAmount);
    tr.dataset.afterDiscount = String(finalSubtotal);
    tr.dataset.tax = String(tax);

    recalculateSummary();
}

function row(data = {}) {
    const tr = document.createElement('tr');
    const discountType = data.discount_type || 'fixed';
    const discountValue = data.discount_value ?? data.discount ?? 0;

    tr.innerHTML = `
        <td>
            <select class="form-select prod" name="items[${idx}][product_id]" required>
                <option value="">${escapeHtml(discountLabels.select)}</option>
                ${products.map(product => `
                    <option value="${product.id}" ${String(data.product_id) === String(product.id) ? 'selected' : ''}>
                        ${escapeHtml(product.name)}
                    </option>
                `).join('')}
            </select>
        </td>
        <td>
            <input class="form-control qty" type="number" step="0.0001" min="0.0001"
                   name="items[${idx}][quantity]" value="${data.quantity ?? 1}" required>
        </td>
        <td>
            <input class="form-control" type="number" step="0.0001" min="0"
                   name="items[${idx}][bundle_quantity]" value="${data.bundle_quantity ?? ''}"
                   placeholder="{{ __('Optional') }}">
        </td>
        <td>
            <input class="form-control price" type="number" step="0.0001" min="0"
                   name="items[${idx}][unit_price]" value="${data.unit_price ?? 0}" required>
        </td>
        <td>
            <select class="form-select discount-type" name="items[${idx}][discount_type]" required>
                <option value="fixed" ${discountType === 'fixed' ? 'selected' : ''}>${escapeHtml(discountLabels.fixed)}</option>
                <option value="percentage" ${discountType === 'percentage' ? 'selected' : ''}>${escapeHtml(discountLabels.percentage)}</option>
            </select>
        </td>
        <td>
            <input class="form-control discount-value" type="number" step="0.0001" min="0"
                   name="items[${idx}][discount_value]" value="${discountValue}">
            <div class="invalid-feedback discount-error"></div>
        </td>
        <td>
            <input class="form-control discount-amount bg-light" type="text" value="0.00" readonly tabindex="-1">
        </td>
        <td>
            <input class="form-control tax" type="number" step="0.01" min="0"
                   name="items[${idx}][tax]" value="${data.tax ?? 0}">
        </td>
        <td>
            <input class="form-control line-subtotal bg-light fw-semibold" type="text" value="0.00" readonly tabindex="-1">
        </td>
        <td>
            <button type="button" class="btn btn-sm btn-outline-danger remove-item">×</button>
        </td>
    `;

    tr.querySelector('.prod').addEventListener('change', event => {
        const product = products.find(item => String(item.id) === event.target.value);
        if (product) {
            tr.querySelector('.price').value = product.price;
        }
        recalculateRow(tr);
    });

    ['.qty', '.price', '.discount-value', '.tax'].forEach(selector => {
        tr.querySelector(selector).addEventListener('input', () => recalculateRow(tr));
    });

    tr.querySelector('.discount-type').addEventListener('change', () => recalculateRow(tr));

    tr.querySelector('.remove-item').addEventListener('click', () => {
        tr.remove();
        recalculateSummary();
    });

    document.querySelector('#items-table tbody').appendChild(tr);
    recalculateRow(tr);
    idx++;
}

document.getElementById('add-item').addEventListener('click', () => row());
document.querySelectorAll('.invoice-calc').forEach(input => {
    input.addEventListener('input', recalculateSummary);
});

(existing.length ? existing : [{}]).forEach(row);
recalculateSummary();
</script>
@endpush
