<?php $__env->startSection('title', $expense->expense_no); ?>
<?php $__env->startSection('heading', 'Expense ' . $expense->expense_no); ?>

<?php $__env->startSection('actions'); ?>
    <?php if($expense->status === 'draft'): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.edit')): ?>
            <a href="<?php echo e(route('expenses.edit', $expense)); ?>" class="btn btn-outline-primary">Edit</a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.post')): ?>
            <form class="d-inline" method="POST" action="<?php echo e(route('expenses.post', $expense)); ?>">
                <?php echo csrf_field(); ?>
                <button class="btn btn-success">Post Expense</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?><div class="card card-body"><dl class="row mb-0"><dt class="col-sm-3">Date</dt><dd class="col-sm-9"><?php echo e($expense->expense_date->format('Y-m-d')); ?></dd><dt class="col-sm-3">Category</dt><dd class="col-sm-9"><?php echo e($expense->category->name); ?></dd><dt class="col-sm-3">Expense Account</dt><dd class="col-sm-9"><?php echo e($expense->expenseAccount->code); ?> - <?php echo e($expense->expenseAccount->name); ?></dd><dt class="col-sm-3">Payment Account</dt><dd class="col-sm-9"><?php echo e($expense->paymentAccount->code); ?> - <?php echo e($expense->paymentAccount->name); ?></dd><dt class="col-sm-3">Amount</dt><dd class="col-sm-9"><?php echo e(number_format($expense->amount,2)); ?></dd><dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?php echo e($expense->status); ?></dd></dl></div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/expenses/show.blade.php ENDPATH**/ ?>