<?php $__env->startSection('title','Users'); ?> <?php $__env->startSection('heading','Users'); ?>
<?php $__env->startSection('actions'); ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.create')): ?><a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>">Add User</a><?php endif; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
<form class="row g-2 mb-3"><div class="col-md-5"><input class="form-control" name="q" value="<?php echo e(request('q')); ?>" placeholder="Name, username or email"></div><div class="col"><button class="btn btn-outline-primary">Search</button></div></form>
<div class="table-responsive"><table class="table align-middle">
<thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead>
<tbody><?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr>
<td><?php echo e($user->name); ?></td><td><?php echo e($user->username); ?></td><td><?php echo e($user->email); ?></td>
<td><?php echo e($user->roles->pluck('name')->join(', ')); ?></td><td><?php echo e(ucfirst($user->status)); ?></td>
<td class="text-end"><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.edit')): ?><a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('users.edit',$user)); ?>">Edit</a><?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.delete')): ?><form class="d-inline" method="POST" action="<?php echo e(route('users.destroy',$user)); ?>" onsubmit="return confirm('Delete user?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Delete</button></form><?php endif; ?></td>
</tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="text-muted">No users.</td></tr><?php endif; ?></tbody></table></div>
<?php echo e($users->links()); ?>

</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\erp-system\resources\views/users/index.blade.php ENDPATH**/ ?>