<?php $__env->startSection('title',__('Supplier Ledger')); ?> <?php $__env->startSection('heading',__('Supplier Ledger: ').$supplier->name); ?>
<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
<form class="row g-2 mb-3">
<div class="col-md-3"><input class="form-control" type="date" name="from_date" value="<?php echo e(request('from_date')); ?>"></div>
<div class="col-md-3"><input class="form-control" type="date" name="to_date" value="<?php echo e(request('to_date')); ?>"></div>
<div class="col-md-3"><input class="form-control" name="type" value="<?php echo e(request('type')); ?>" placeholder="<?php echo e(__('Entry type')); ?>"></div>
<div class="col"><button class="btn btn-outline-primary"><?php echo e(__('Filter')); ?></button></div>
</form>
<div class="table-responsive"><table class="table"><thead><tr><th><?php echo e(__('Date')); ?></th><th><?php echo e(__('Reference')); ?></th><th><?php echo e(__('Type')); ?></th><th><?php echo e(__('Description')); ?></th><th class="text-end"><?php echo e(__('Debit')); ?></th><th class="text-end"><?php echo e(__('Credit')); ?></th><th class="text-end"><?php echo e(__('Balance')); ?></th></tr></thead><tbody>
<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($e->transaction_date->format('Y-m-d')); ?></td><td><?php echo e($e->reference_no); ?></td><td><?php echo e(__(ucwords(str_replace('_',' ',$e->entry_type)))); ?></td><td><?php echo e($e->description); ?></td><td class="text-end"><?php echo e(number_format((float)$e->debit,2)); ?></td><td class="text-end"><?php echo e(number_format((float)$e->credit,2)); ?></td><td class="text-end"><?php echo e(number_format((float)$e->running_balance,2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody><tfoot><tr class="fw-bold"><td colspan="6"><?php echo e(__('Closing Balance')); ?></td><td class="text-end"><?php echo e(number_format((float)$running,2)); ?></td></tr></tfoot></table></div>
<div class="small text-muted"><?php echo e(__('Positive = company owes supplier. Negative = supplier advance.')); ?></div>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home3/intrigueit/erp.intrigueit.co/resources/views/suppliers/ledger.blade.php ENDPATH**/ ?>